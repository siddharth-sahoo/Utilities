/**
 * This package contains required classes for dynamic compilation
 * of source code.
 * @author siddharth.s
 */
package com.awesome.pro.utilities.compile;